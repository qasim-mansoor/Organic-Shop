export const environment = {
  production: true,
  firebase: {
    apiKey: "AIzaSyBKbdXo6oPsbHbP5gff4SkkyEtqTYi7rOk",
    authDomain: "oshop-9c5c0.firebaseapp.com",
    databaseURL: "https://oshop-9c5c0.firebaseio.com",
    projectId: "oshop-9c5c0",
    storageBucket: "oshop-9c5c0.appspot.com",
    messagingSenderId: "42127342631",  
  }
};
