// The file contents for the current environment will overwrite these during build.
// The build system defaults to the dev environment which uses `environment.ts`, but if you do
// `ng build --env=prod` then `environment.prod.ts` will be used instead.
// The list of which env maps to which file can be found in `.angular-cli.json`.

export const environment = {
  production: false,
  firebase: {
    apiKey: "AIzaSyBKbdXo6oPsbHbP5gff4SkkyEtqTYi7rOk",
    authDomain: "oshop-9c5c0.firebaseapp.com",
    databaseURL: "https://oshop-9c5c0.firebaseio.com",
    projectId: "oshop-9c5c0",
    storageBucket: "oshop-9c5c0.appspot.com",
    messagingSenderId: "42127342631",   
  }
};
